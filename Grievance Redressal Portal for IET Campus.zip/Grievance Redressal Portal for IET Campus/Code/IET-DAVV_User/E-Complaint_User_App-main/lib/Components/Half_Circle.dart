import 'package:flutter/material.dart';
import 'package:flutter/painting.dart';

class DrowHalfCircle extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    Paint paint = Paint()..color = Colors.black;
    canvas.drawArc(
        Rect.fromCenter(
          center: Offset(20, 100),
          width: 50,
          height: 50,
        ),
        3.14,
        3.14,
        false,
        paint);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) {
    return false;
    // throw UnimplementedError();
  }
}
