import 'package:flutter/material.dart';

showMsgDialog(context, item) {
  showDialog(
      context: context,
      builder: (context) {
        return item;
      });
}
