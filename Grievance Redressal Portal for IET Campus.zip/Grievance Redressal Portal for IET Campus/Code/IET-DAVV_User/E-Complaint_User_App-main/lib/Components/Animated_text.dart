import 'package:animated_text_kit/animated_text_kit.dart';
import 'package:flutter/material.dart';

class ShowAnimatedText extends StatelessWidget {
  final AnimatedText text;

  const ShowAnimatedText({
    Key key,
    @required this.text,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return DefaultTextStyle(
      style:
          TextStyle(color: Colors.black, fontFamily: 'fredoka', fontSize: 30),
      child: AnimatedTextKit(
        totalRepeatCount: 1,
        isRepeatingAnimation: true,
        pause: Duration(seconds: 2),
        animatedTexts: [text],
      ),
    );
  }
}
