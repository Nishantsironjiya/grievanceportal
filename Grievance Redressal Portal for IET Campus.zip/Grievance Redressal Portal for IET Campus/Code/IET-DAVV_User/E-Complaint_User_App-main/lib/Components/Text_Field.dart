import 'package:flutter/material.dart';

class TextFieldArea extends StatelessWidget {
  const TextFieldArea({
    Key key,
    this.hint,
    this.fun,
    this.color = const Color(0xffF5F5F5),
    this.tap,
    this.suffix,
    this.submit,
    this.state = false,
    this.maxline = 1,
    this.ctrl,
  }) : super(key: key);
  final TextEditingController ctrl;
  final Color color;
  final String hint;
  final Function fun;
  final Function tap;
  final Widget suffix;
  final bool state;
  final int maxline;
  final Function submit;
  @override
  Widget build(BuildContext context) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(12),
      child: TextField(
        controller: ctrl,
        maxLines: maxline,
        obscureText: state,
        onTap: tap,
        onSubmitted: submit,
        onChanged: fun,
        enableSuggestions: true,
        decoration: InputDecoration(
          suffix: suffix,
          contentPadding:
              EdgeInsets.only(left: 20, top: 15, bottom: 15, right: 20),
          filled: true,
          fillColor: color,
          hintText: hint,
          border: InputBorder.none,
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: BorderSide(
              color: Colors.orange, //Color(0xff8ACAC0),
            ),
          ),
        ),
      ),
    );
  }
}
