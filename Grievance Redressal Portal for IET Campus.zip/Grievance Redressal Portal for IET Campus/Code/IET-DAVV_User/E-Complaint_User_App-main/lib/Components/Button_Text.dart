import 'package:flutter/material.dart';

class ButtonText extends StatelessWidget {
  final String s;
  final Color color;
  const ButtonText({Key key, this.s, this.color}) : super(key: key);
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.symmetric(horizontal: 50, vertical: 20),
      child: Text(
        s,
        style: TextStyle(
          color: color != null ? color : Colors.white,
          fontWeight: FontWeight.bold,
          letterSpacing: 2,
        ),
      ),
    );
  }
}
