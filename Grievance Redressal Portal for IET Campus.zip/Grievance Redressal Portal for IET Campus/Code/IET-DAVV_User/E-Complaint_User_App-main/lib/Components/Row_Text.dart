import 'package:flutter/material.dart';

class RowText extends StatelessWidget {
  final String text1;
  final String text2;
  final Function fun;
  const RowText({
    Key key,
    this.text1,
    this.text2,
    this.fun,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Flexible(
          child: Text(
            text1,
            style: TextStyle(color: Colors.grey),
          ),
        ),
        Flexible(
          child: TextButton(
            style: ButtonStyle(
              overlayColor:
                  MaterialStateProperty.resolveWith((states) => Colors.black12),
            ),
            onPressed: fun,
            child: Text(
              text2,
              style: TextStyle(color: Colors.black, fontSize: 16),
            ),
          ),
        ),
      ],
    );
  }
}
