import 'dart:ui';

import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:provider/provider.dart';
import 'package:iet_user_app/Components/Button.dart';
import 'package:iet_user_app/Components/create_space.dart';
import 'package:iet_user_app/Components/showLoading.dart';
import 'package:iet_user_app/Firebase/FirebaseAuth.dart';
import 'package:iet_user_app/Functions/Platform_Check.dart';
import 'package:iet_user_app/Provider/Data_Provider.dart';
import 'package:iet_user_app/Views/Home.dart';

Widget drawer(context) {
  DataProvider provider = Provider.of<DataProvider>(context, listen: false);
  return Container(
    decoration: BoxDecoration(
      color: Color(0xffFFFFFF),
      borderRadius: BorderRadius.only(
        topRight: Radius.elliptical(100, 100),
      ),
    ),
    margin: EdgeInsets.only(
        right: MediaQuery.of(context).size.width *
            (checkPlatform() ? (0.20) : (0.70))),
    padding: EdgeInsets.all(22),
    child: Column(
      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
      children: [
        DrawerHeader(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              CircleAvatar(
                backgroundColor: Colors.orange,
                radius: 50,
                backgroundImage: provider.getImage,
              ),
              space(v: 10),
              Text(
                provider.getUserName,
                style: TextStyle(
                  color: Colors.orange,
                  fontFamily: 'Pacific',
                ),
              ),
            ],
          ),
        ),
        Divider(
          color: Colors.black,
          thickness: 1.5,
          indent: 55,
          endIndent: 65,
        ),
        ListTile(
          leading: Icon(Icons.email_rounded),
          title: Text(provider.getUserEmail),
        ),
        ListTile(
          leading: Icon(Icons.phone),
          title: Text(provider.getUserPhoneNumber),
        ),
        ListTile(
          leading: FaIcon(FontAwesomeIcons.university),
          title: Text(provider.getDepartment),
        ),
        Spacer(),
        SignInOutButton(
            fun: () async {
              showLoading(context);
              await signOut();
              Navigator.pop(context);
              provider.cleardata();
              Navigator.pushAndRemoveUntil(
                  context,
                  MaterialPageRoute(builder: (context) => Home()),
                  (route) => false);
            },
            text: 'Logout')
      ],
    ),
  );
}
