import 'package:flutter/widgets.dart';

SizedBox space({double v = 25}) {
  return SizedBox(
    height: v,
  );
}
