import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:iet_user_app/Components/Button.dart';
import 'package:iet_user_app/Components/Text_Field.dart';
import 'package:iet_user_app/Components/create_space.dart';
import 'package:iet_user_app/Components/showLoading.dart';
import 'package:iet_user_app/Firebase/FirebaseFirestore.dart';
import 'package:iet_user_app/Functions/Platform_Check.dart';

String _text;
final TextEditingController _ctrl = TextEditingController();

class SearchButton extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
      height: 45,
      width: 45,
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20),
      ),
      child: Center(
        child: IconButton(
          tooltip: 'Check Your Complaint Status',
          icon: FaIcon(
            FontAwesomeIcons.search,
            color: Colors.orange,
          ),
          onPressed: () async {
            // checkPlatform()
            // ? showModalBottomSheet(
            //     isScrollControlled: true,
            //     backgroundColor: Colors.transparent,
            //     context: context,
            //     builder: (context) => Container(
            //           padding: EdgeInsets.all(10),
            //           decoration: BoxDecoration(
            //             color: Color(0xffFFFFFF),
            //             borderRadius: BorderRadius.only(
            //               topLeft: Radius.circular(25),
            //               topRight: Radius.circular(25),
            //             ),
            //           ),
            //           child: buildColumn(context),
            //         ))
            // :
            showDialog(
              context: context,
              builder: (context) => Dialog(
                insetPadding: !checkPlatform()
                    ? EdgeInsets.symmetric(
                        horizontal: MediaQuery.of(context).size.width * 0.35)
                    : EdgeInsets.symmetric(horizontal: 40.0, vertical: 24.0),
                elevation: 10,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(20),
                ),
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 20),
                  child: buildColumn(context),
                ),
              ),
            );
          },
        ),
      ),
    );
  }

  Column buildColumn(context) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
      children: [
        space(v: 20),
        TextFieldArea(
          hint: 'Enter Complaint Referance Number',
          fun: (v) {
            _text = v;
          },
        ),
        space(v: 20),
        SignInOutButton(
            fun: () async {
              showLoading(context);
              String _ans = await searchComplaintStatus(ref: _text);
              _text = null;
              _ctrl.clear();
              Navigator.pop(context);
              Navigator.pop(context);
              showDialog(
                  context: context,
                  builder: (context) => Dialog(
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(20),
                        ),
                        child: Container(
                          padding: EdgeInsets.all(30),
                          child: Text(
                            _ans,
                            textAlign: TextAlign.center,
                            style: TextStyle(
                              wordSpacing: 2,
                              fontWeight: FontWeight.bold,
                              fontFamily: 'Coda',
                              fontSize: 20,
                            ),
                          ),
                        ),
                      ));
            },
            text: 'Search'),
        space(v: 20),
      ],
    );
  }
}
