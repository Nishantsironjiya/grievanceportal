import 'package:animated_text_kit/animated_text_kit.dart';
import 'package:flutter/material.dart';
import 'package:iet_user_app/Functions/Platform_Check.dart';

class AnimatedAppName extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.orange,
      body: Center(
        child: checkPlatform()
            ? SizedBox(
                child: TextLiquidFill(
                  loadDuration: Duration(seconds: 3),
                  textAlign: TextAlign.center,
                  text: 'IET-DAVV Complaint Portal',
                  waveColor: Colors.white,
                  boxBackgroundColor: Colors.orange,
                  textStyle: TextStyle(
                    fontFamily: 'fredoka',
                    fontSize: 50,
                  ),
                  boxHeight: 500,
                ),
              )
            : DefaultTextStyle(
                textAlign: TextAlign.center,
                style: const TextStyle(
                  fontFamily: 'fredoka',
                  color: Colors.white,
                  fontSize: 50,
                ),
                child: AnimatedTextKit(
                  pause: Duration(milliseconds: 0),
                  displayFullTextOnTap: true,
                  animatedTexts: [
                    WavyAnimatedText('IET-DAVV'),
                    WavyAnimatedText('Complaint'),
                    WavyAnimatedText('Portal'),
                  ],
                  isRepeatingAnimation: false,
                ),
              ),
      ),
    );
  }
}

// ShowAnimatedText(
//   text: ScaleAnimatedText('iet Complaint Portal'),
// ),
