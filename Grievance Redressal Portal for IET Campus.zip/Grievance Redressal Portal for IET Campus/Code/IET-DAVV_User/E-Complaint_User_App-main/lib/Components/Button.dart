import 'package:flutter/material.dart';

class SignInOutButton extends StatelessWidget {
  final Function fun;
  final String text;
  const SignInOutButton({
    Key key,
    @required this.fun,
    @required this.text,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: double.infinity,
      height: 50,
      child: ClipRRect(
        borderRadius: BorderRadius.circular(12),
        child: ElevatedButton(
          style: ButtonStyle(
            backgroundColor: MaterialStateProperty.resolveWith(
                (states) => Colors.orange), //Color(0xff8ACAC0)),
          ),
          onPressed: fun,
          child: Text(
            text,
            style: TextStyle(
              color: Colors.white,
              fontWeight: FontWeight.bold,
              letterSpacing: 2,
            ),
          ),
        ),
      ),
    );
  }
}
