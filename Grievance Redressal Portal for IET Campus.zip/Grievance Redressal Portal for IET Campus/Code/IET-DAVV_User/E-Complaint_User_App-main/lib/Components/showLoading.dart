import 'package:flutter/material.dart';

showLoading(context) {
  showDialog(
      context: context,
      builder: (context) => Center(child: CircularProgressIndicator()));
}
