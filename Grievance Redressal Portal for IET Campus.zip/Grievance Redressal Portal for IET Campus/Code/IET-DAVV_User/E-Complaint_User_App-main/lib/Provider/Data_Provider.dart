import 'dart:io';
import 'dart:typed_data';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:iet_user_app/Firebase/FirebaseFirestore.dart';

enum UserType { Student, Teacher, Other }

class DataProvider extends ChangeNotifier {
  String _userName;

  get getUserName {
    return _userName;
  }

  set setUserName(String name) {
    _userName = name;
    notifyListeners();
  }

  UserType _userType;

  get getUserType {
    return _userType;
  }

  String getUserTypeForDB() {
    if (toggleValueList[0])
      return 'Student';
    else if (toggleValueList[1])
      return 'Teacher';
    else if (toggleValueList[2])
      return 'Other';
    else
      return 'Error';
  }

  set setUserType(UserType type) {
    _userType = type;
    notifyListeners();
  }

  String _userEmail;

  get getUserEmail {
    return _userEmail;
  }

  set setUserEmail(String id) {
    _userEmail = id;
    notifyListeners();
  }

  String _userPhoneNumber;

  get getUserPhoneNumber {
    return _userPhoneNumber;
  }

  set setUserPhoneNumber(String s) {
    _userPhoneNumber = s;
  }

  String _department = 'Select Department';

  get getDepartment {
    return _department;
  }

  set setDeparment(String dept) {
    _department = dept;
    notifyListeners();
  }

  String _enrollment;

  get getEnrollment {
    return _enrollment;
  }

  set setEnrollment(String id) {
    _enrollment = id;
    notifyListeners();
  }

  String _profileURL;

  get getProfileURL {
    return _profileURL;
  }

  set setProfileURL(String url) {
    _profileURL = url;
    notifyListeners();
  }

// Toggle Button Values
  List<bool> toggleValueList = [false, false, false];
  List<Color> toggleColorList = [Colors.grey, Colors.grey, Colors.grey];

  void changeToggleValue({int index}) {
    switch (index) {
      case 0:
        toggleValueList[0] = true;
        toggleColorList[0] = Colors.black;
        toggleValueList[1] = false;
        toggleColorList[1] = Colors.grey;
        toggleValueList[2] = false;
        toggleColorList[2] = Colors.grey;
        setUserType = UserType.Student;
        break;
      case 1:
        toggleValueList[1] = true;
        toggleValueList[0] = false;
        toggleValueList[2] = false;
        toggleColorList[1] = Colors.black;
        toggleColorList[0] = Colors.grey;
        toggleColorList[2] = Colors.grey;
        setUserType = UserType.Teacher;
        break;
      case 2:
        toggleValueList[2] = true;
        toggleColorList[2] = Colors.black;
        toggleValueList[1] = false;
        toggleColorList[1] = Colors.grey;
        toggleValueList[0] = false;
        toggleColorList[0] = Colors.grey;
        setUserType = UserType.Other;
        break;
    }
    notifyListeners();
  }

  bool _isProgress = false;

  get getProgressStatus {
    return _isProgress;
  }

  set setProgressStatus(bool status) {
    _isProgress = status;
    notifyListeners();
  }

  dynamic _platform;

  get getPlatform {
    return _platform;
  }

  set setPlatform(bool p) {
    _platform = p;
    notifyListeners();
  }

  bool _secureText0 = true;
  bool _secureText1 = true;

  get getSecureText0Status {
    return _secureText0;
  }

  void changeSecureText0Status() {
    _secureText0 = !_secureText0;
    notifyListeners();
  }

  get getSecureText1Status {
    return _secureText1;
  }

  void changeSecureText1Status() {
    _secureText1 = !_secureText1;
    notifyListeners();
  }

  Color text1FieldColor = Color(0xffF5F5F5);
  Color text2FieldColor = Color(0xffF5F5F5);

  set setfield1Color(Color c) {
    text1FieldColor = c;
    notifyListeners();
  }

  set setfield2Color(Color c) {
    text2FieldColor = c;
    notifyListeners();
  }

  bool _validateEmailError;

  get getEmailError {
    return _validateEmailError;
  }

  set setEmailError(bool s) {
    _validateEmailError = s;
    notifyListeners();
  }

  void cleardata() {
    _userEmail = '';
    _userName = '';
    _enrollment = '';
    _userPhoneNumber = '';
    _img = AssetImage('assets/no-user.png');
    _department = 'Select Department';
    _clipColor = Colors.grey;
    toggleValueList[0] = false;
    toggleColorList[0] = Colors.grey;
    toggleValueList[1] = false;
    toggleColorList[1] = Colors.grey;
    toggleValueList[2] = false;
    toggleColorList[2] = Colors.grey;
  }

  String localPathOfImage;
  Uint8List bytesOfImage;
  ImageProvider<Object> _img = AssetImage('assets/no-user.png');

  get getImage {
    return _img;
  }

  void resetImage() {
    _img = AssetImage('assets/no-user.png');
    notifyListeners();
  }

  void imageLoadedIndicater() {
    _img = AssetImage('assets/loaded.png');
    notifyListeners();
  }

  set setLocalImage(File file) {
    _img = FileImage(file);
    notifyListeners();
  }

  set setNetworkImage(String s) {
    _img = NetworkImage(s);
    notifyListeners();
  }

  set setWebImage(Uint8List bytes) {
    _img = MemoryImage(bytes);
    notifyListeners();
  }

  Future<void> setUserData() async {
    try {
      DocumentSnapshot _data = await fatchUserData(email: _userEmail);
      setUserPhoneNumber = _data['Phone'];
      setDeparment = _data['Department'];
      setUserEmail = _data['Email'];
      setEnrollment = _data['Enrollment'];
      setUserName = _data['Name'];
      setNetworkImage = _data['Profile'];
    } catch (e) {
      print(e);
    }
  }

  Color _clipColor = Colors.grey;
  get getClipColor {
    return _clipColor;
  }

  set setClipColor(Color s) {
    _clipColor = s;
    notifyListeners();
  }

  String _webAttachmentUrl;
  get getwebAttachmentUrl {
    return _webAttachmentUrl;
  }

  set setwebAttachmentUrl(String s) {
    if (s != null && s.length != 0) {
      _webAttachmentUrl = s;
      if (s != null && s.length != 0) notifyListeners();
    }
  }

  String _webProfileUrl;
  get getwebProfileUrl {
    return _webProfileUrl;
  }

  set setwebProfileUrl(String s) {
    _webProfileUrl = s;
    notifyListeners();
  }

  ImageProvider<Object> signUpImage =
      AssetImage('assets/pexels-linda-ellershein-3127880.jpg');
  ImageProvider<Object> signInImage =
      AssetImage('assets/pexels-henry-&-co-1406282.jpg');
  ImageProvider<Object> resetPassImage = AssetImage('assets/2.jpg');
  ImageProvider<Object> complaintImage = AssetImage('assets/sample.jpg');
}
