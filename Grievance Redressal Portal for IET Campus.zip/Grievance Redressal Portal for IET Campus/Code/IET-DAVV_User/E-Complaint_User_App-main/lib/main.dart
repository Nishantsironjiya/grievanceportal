import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:iet_user_app/Components/Animated_App_name.dart';
import 'package:iet_user_app/Views/Splash.dart';
import 'Provider/Data_Provider.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return FutureBuilder(
      future: Firebase.initializeApp(),
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.done)
          return ChangeNotifierProvider<DataProvider>(
              create: (context) => DataProvider(),
              child: MaterialApp(home: Splash()));
        if (snapshot.hasError)
          return MaterialApp(
            home: Center(
              child: Text('Something Went Wrong'),
            ),
          );
        return MaterialApp(
          home: AnimatedAppName(),
        );
      },
    );
  }
}
