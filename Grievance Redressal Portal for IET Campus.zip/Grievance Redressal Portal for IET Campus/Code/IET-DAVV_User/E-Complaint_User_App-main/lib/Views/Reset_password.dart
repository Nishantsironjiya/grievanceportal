import 'package:animated_text_kit/animated_text_kit.dart';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:provider/provider.dart';
import 'package:iet_user_app/Components/Animated_text.dart';
import 'package:iet_user_app/Components/Button.dart';
import 'package:iet_user_app/Components/ShowDialog.dart';
import 'package:iet_user_app/Components/Text_Field.dart';
import 'package:iet_user_app/Components/create_space.dart';
import 'package:iet_user_app/Components/showLoading.dart';
import 'package:iet_user_app/Firebase/FirebaseAuth.dart';
import 'package:iet_user_app/Functions/Platform_Check.dart';
import 'package:iet_user_app/Provider/Data_Provider.dart';

class ResetPassword extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    String _email;
    return Scaffold(
      backgroundColor: Color(0xffFFFFFF),
      body: Row(
        children: [
          if (!checkPlatform())
            Expanded(
              flex: 3,
              child: Container(
                decoration: BoxDecoration(
                    image: DecorationImage(
                  image: Provider.of<DataProvider>(context, listen: false)
                      .resetPassImage,
                  fit: BoxFit.cover,
                )),
              ),
            ),
          Container(
            child: Expanded(
              flex: 2,
              child: LayoutBuilder(
                builder: (BuildContext context, BoxConstraints constraints) =>
                    Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 20),
                  child: SingleChildScrollView(
                    physics: ClampingScrollPhysics(),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.end,
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        Container(
                          constraints: constraints / 2,
                          child: Center(
                            child: FaIcon(
                              FontAwesomeIcons.shieldAlt,
                              size: 100,
                              color: Colors.orange, //Color(0xff8ACAC0),
                            ),
                          ),
                        ),
                        Container(
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              ShowAnimatedText(
                                text: TyperAnimatedText('Reset Password'),
                              ),
                              space(v: 20),
                              Text(
                                'Enter your email address you used to sign in to.',
                                style: TextStyle(color: Colors.grey),
                              ),
                              space(v: 40),
                              TextFieldArea(
                                hint: 'Email address',
                                fun: (v) {
                                  _email = v;
                                },
                              ),
                              space(v: 30),
                              SignInOutButton(
                                  fun: () async {
                                    showLoading(context);
                                    String result =
                                        await resetPassword(email: _email);
                                    Navigator.pop(context);
                                    showMsgDialog(
                                        context,
                                        SimpleDialog(
                                          contentPadding: EdgeInsets.all(20),
                                          title: Text(result),
                                          children: [
                                            TextButton(
                                                onPressed: () {
                                                  Navigator.pop(context);
                                                  Navigator.pop(context);
                                                },
                                                child: Text('OK'))
                                          ],
                                        ));
                                  },
                                  text: 'Reset password'),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
