import 'dart:ui';

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:provider/provider.dart';
import 'package:iet_user_app/Components/App_Drawer.dart';
import 'package:iet_user_app/Components/Button.dart';
import 'package:iet_user_app/Components/ShowDialog.dart';
import 'package:iet_user_app/Components/SnackBar.dart';
import 'package:iet_user_app/Components/Text_Field.dart';
import 'package:iet_user_app/Components/showLoading.dart';
import 'package:iet_user_app/Firebase/FirebaseAuth.dart';
import 'package:iet_user_app/Firebase/FirebaseFirestore.dart';
import 'package:iet_user_app/Functions/ImagePicker.dart';
import 'package:iet_user_app/Functions/Upload_image_web.dart';
import 'package:iet_user_app/Provider/Data_Provider.dart';
import 'package:iet_user_app/Views/Home.dart';
import 'package:iet_user_app/Views/Sign_In.dart';

String _subject;
String _complaint;
String _attachment;
final _sctrl = TextEditingController();
final _cctrl = TextEditingController();

class Complaint extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return isVerifiedEmail()
        ? Consumer<DataProvider>(
            builder: (context, provider, child) => Scaffold(
              backgroundColor: Color(0xffFFFFFF), //Color(0xffDEE8EB),
              appBar: AppBar(
                title: Text(
                  'Complaint',
                  style: TextStyle(
                    fontFamily: 'fredoka',
                    color: Colors.black,
                    // letterSpacing: 1,
                  ),
                ),
                centerTitle: true,
                elevation: 0,
                backgroundColor: Colors.transparent,
                iconTheme: IconThemeData(color: Colors.black),
              ),
              drawer: drawer(context),
              body: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20),
                child: ListView(
                  children: [
                    SizedBox(
                      height: 30,
                    ),
                    TextFieldArea(
                      ctrl: _sctrl,
                      hint: 'Subject',
                      fun: (value) => _subject = value,
                    ),
                    SizedBox(
                      height: 20,
                    ),
                    Stack(
                      alignment: Alignment.bottomRight,
                      children: [
                        TextFieldArea(
                          ctrl: _cctrl,
                          hint: 'Write Your Complaint Here...',
                          maxline: 20,
                          fun: (value) => _complaint = value,
                        ),
                        IconButton(
                            tooltip: 'Add Attachment',
                            icon: FaIcon(
                              FontAwesomeIcons.paperclip,
                              color: provider.getClipColor,
                            ),
                            onPressed: () async {
                              if (!kIsWeb) {
                                _attachment = await getImage(context);
                                if (_attachment != null)
                                  provider.setClipColor = Colors.orange;
                              } else {
                                await uploadWebAttachment(context: context);
                              }
                            })
                      ],
                    ),
                    SizedBox(
                      height: 20,
                    ),
                    SignInOutButton(
                      fun: () async {
                        if (_subject == null || _subject.length == 0) {
                          showSnakbar(
                              context: context, message: 'Enter Subject');
                        } else if (_complaint == null || _complaint.length == 0)
                          showSnakbar(
                              context: context, message: 'Enter Complaint');
                        else {
                          showLoading(context);
                          String _id = await submitComplaint(
                            context: context,
                            subject: _subject,
                            complaint: _complaint,
                            attachment: _attachment,
                          );
                          if (_id != null) {
                            showMsgDialog(
                                context,
                                AlertDialog(
                                  content: SelectableText(
                                    'Complaint Number : $_id\nSave this for Future Referance',
                                    style: TextStyle(
                                        fontWeight: FontWeight.w400,
                                        fontFamily: 'PT'),
                                  ),
                                  title: Text(
                                    'Submitted Succesfully',
                                    textAlign: TextAlign.center,
                                    style: TextStyle(fontFamily: 'PT'),
                                  ),
                                  actions: [
                                    ElevatedButton(
                                      style: ButtonStyle(
                                        shape: MaterialStateProperty
                                            .resolveWith((states) =>
                                                RoundedRectangleBorder(
                                                  borderRadius:
                                                      BorderRadius.circular(10),
                                                )),
                                        backgroundColor:
                                            MaterialStateProperty.resolveWith(
                                                (states) => Colors.orange),
                                      ),
                                      onPressed: () {
                                        resetData();
                                        provider.setClipColor = Colors.grey;
                                        Navigator.pop(context);
                                      },
                                      child: Text('OK'),
                                    ),
                                  ],
                                ));
                          }
                        }
                      },
                      text: 'Submit',
                    ),
                  ],
                ),
              ),
            ),
          )
        : Scaffold(
            body: Center(
              child: AlertDialog(
                elevation: 10,
                title: Text(
                  'Email verification is required!',
                  style: TextStyle(fontFamily: 'PT'),
                ),
                actions: [
                  ElevatedButton(
                      style: ButtonStyle(
                        shape: MaterialStateProperty.resolveWith(
                            (states) => RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(10),
                                )),
                        backgroundColor: MaterialStateProperty.resolveWith(
                            (states) => Colors.orange),
                      ),
                      onPressed: () async {
                        showLoading(context);
                        try {
                          await sendVerificationEmail();
                          await signOut();
                          Navigator.pop(context);
                          Navigator.pushReplacement(
                              context,
                              MaterialPageRoute(
                                  builder: (context) => SignIn()));
                        } catch (e) {
                          Navigator.pop(context);
                          showSnakbar(context: context, message: e.message);
                        }
                      },
                      child: Text('Get email again')),
                  ElevatedButton(
                      style: ButtonStyle(
                        shape: MaterialStateProperty.resolveWith(
                            (states) => RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(10),
                                )),
                        backgroundColor: MaterialStateProperty.resolveWith(
                            (states) => Colors.orange),
                      ),
                      onPressed: () {
                        Navigator.pushReplacement(context,
                            MaterialPageRoute(builder: (context) => Home()));
                      },
                      child: Text('Cancel'))
                ],
              ),
            ),
          );
  }
}

resetData() {
  _cctrl.clear();
  _sctrl.clear();
  _attachment = null;
  _subject = null;
  _complaint = null;
}
