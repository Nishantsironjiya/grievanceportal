import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:iet_user_app/Components/Button_Text.dart';
import 'package:iet_user_app/Components/Search_Button.dart';
import 'package:iet_user_app/Functions/Platform_Check.dart';
import 'package:iet_user_app/Provider/Data_Provider.dart';
import 'package:iet_user_app/Views/Sign_In.dart';
import 'package:iet_user_app/Views/Sign_Up.dart';

class Home extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final List<Widget> _buttons = [
      Flexible(
        child: ElevatedButton(
          onPressed: () {
            Navigator.push(
                context, MaterialPageRoute(builder: (context) => SignIn()));
          },
          style: ButtonStyle(
            shape:
                MaterialStateProperty.resolveWith((states) => StadiumBorder()),
            elevation: MaterialStateProperty.resolveWith((states) => 20),
            backgroundColor:
                MaterialStateProperty.resolveWith((states) => Colors.orange),
          ),
          child: ButtonText(s: 'Sign in'),
        ),
      ),
      Flexible(
        child: ElevatedButton(
          onPressed: () async {
            await Navigator.push(
                context, MaterialPageRoute(builder: (context) => SignUp()));
          },
          child: ButtonText(s: 'Sign up', color: Colors.green),
          style: ButtonStyle(
            overlayColor: MaterialStateProperty.resolveWith(
                (states) => Colors.orange[50]),
            shape:
                MaterialStateProperty.resolveWith((states) => StadiumBorder()),
            elevation: MaterialStateProperty.resolveWith((states) => 20),
            backgroundColor:
                MaterialStateProperty.resolveWith((states) => Colors.white),
          ),
        ),
      ),
    ];
    return ChangeNotifierProvider<DataProvider>(
      create: (context) => DataProvider(),
      child: MaterialApp(
        home: Scaffold(
          resizeToAvoidBottomInset: false,
          body: Stack(
            fit: StackFit.expand,
            children: [
              Container(
                decoration: BoxDecoration(
                  image: DecorationImage(
                    image: AssetImage('assets/CollegeBackground.jpg'),
                    fit: BoxFit.cover,
                  ),
                ),
              ),
              Container(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [
                      Colors.black87,
                      Colors.black12,
                    ],
                    begin: Alignment.bottomCenter,
                    end: Alignment.topCenter,
                  ),
                ),
                child: Column(
                  children: [
                    Flexible(
                        child: Container(
                      child: Padding(
                        padding: const EdgeInsets.only(top: 40, left: 30),
                        child: Align(
                          alignment: Alignment.topLeft,
                          child: SearchButton(),
                        ),
                      ),
                    )),
                    Spacer(),
                    Expanded(
                      child: Container(
                        child: checkPlatform()
                            ? Column(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceEvenly,
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: _buttons,
                              )
                            : Row(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceEvenly,
                                children: _buttons,
                              ),
                      ),
                    )
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
