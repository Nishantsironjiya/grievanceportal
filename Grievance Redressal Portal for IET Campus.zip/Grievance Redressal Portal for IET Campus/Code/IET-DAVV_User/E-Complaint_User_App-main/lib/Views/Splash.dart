import 'package:flutter/material.dart';
import 'package:iet_user_app/Components/Animated_App_name.dart';
import 'package:iet_user_app/Functions/Platform_Check.dart';
import 'package:iet_user_app/Views/Home.dart';

class Splash extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return FutureBuilder(
      future: Future.delayed(
        Duration(
          seconds: checkPlatform() ? 3 : 7,
        ),
      ),
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.done) return Home();
        return AnimatedAppName();
      },
    );
  }
}
