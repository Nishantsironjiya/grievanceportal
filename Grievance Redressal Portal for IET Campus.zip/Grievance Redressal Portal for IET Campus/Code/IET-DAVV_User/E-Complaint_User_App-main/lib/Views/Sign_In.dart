import 'package:animated_text_kit/animated_text_kit.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:iet_user_app/Components/Animated_text.dart';
import 'package:iet_user_app/Components/Button.dart';
import 'package:iet_user_app/Components/Row_Text.dart';
import 'package:iet_user_app/Components/Text_Field.dart';
import 'package:iet_user_app/Components/create_space.dart';
import 'package:iet_user_app/Components/showLoading.dart';
import 'package:iet_user_app/Firebase/FirebaseAuth.dart';
import 'package:iet_user_app/Functions/Platform_Check.dart';
import 'package:iet_user_app/Provider/Data_Provider.dart';
import 'package:iet_user_app/Views/Complaint.dart';
import 'package:iet_user_app/Views/Reset_password.dart';
import 'package:iet_user_app/Views/Sign_Up.dart';

class SignIn extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    String _passward;
    return Consumer<DataProvider>(
      builder: (context, provider, child) {
        return Scaffold(
          backgroundColor: Color(0xffFFFFFF),
          body: Row(
            children: [
              if (!checkPlatform())
                Expanded(
                  flex: 3,
                  child: Container(
                    decoration: BoxDecoration(
                        image: DecorationImage(
                      image: provider.signInImage,
                      fit: BoxFit.cover,
                    )),
                  ),
                ),
              Expanded(
                flex: 2,
                child: Container(
                  child: LayoutBuilder(
                    builder:
                        (BuildContext context, BoxConstraints constraints) {
                      return Padding(
                        padding:
                            EdgeInsets.symmetric(horizontal: 20, vertical: 20),
                        child: SingleChildScrollView(
                          physics: BouncingScrollPhysics(),
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              space(v: 100),
                              Text(
                                'Hey,',
                                style: TextStyle(
                                    color: Colors.black,
                                    fontFamily: 'log',
                                    fontSize: 30),
                              ),
                              SizedBox(
                                height: 50,
                                child: ShowAnimatedText(
                                  text: TyperAnimatedText('Login Now.'),
                                ),
                              ),
                              RowText(
                                text1: 'If you are new / ',
                                text2: 'Create New',
                                fun: () {
                                  Navigator.push(
                                      context,
                                      MaterialPageRoute(
                                          builder: (context) => SignUp()));
                                },
                              ),
                              SizedBox(
                                height: 30,
                              ),
                              TextFieldArea(
                                hint: 'Email',
                                fun: (v) {
                                  provider.setUserEmail = v;
                                },
                              ),
                              SizedBox(
                                height: 25,
                              ),
                              TextFieldArea(
                                suffix: InkWell(
                                  onTap: () {
                                    provider.changeSecureText0Status();
                                  },
                                  child: Icon(
                                    Icons.remove_red_eye,
                                    size: 15,
                                  ),
                                ),
                                state: provider.getSecureText0Status,
                                color: provider.text2FieldColor,
                                hint: 'Password',
                                fun: (v) {
                                  _passward = v;
                                },
                              ),
                              SizedBox(
                                height: 17,
                              ),
                              RowText(
                                text1: 'Forgot Passcode ? / ',
                                text2: 'Reset',
                                fun: () {
                                  Navigator.push(
                                      context,
                                      MaterialPageRoute(
                                          builder: (context) =>
                                              ResetPassword()));
                                },
                              ),
                              SizedBox(
                                height: 60,
                              ),
                              SignInOutButton(
                                text: 'Login',
                                fun: () async {
                                  showLoading(context);
                                  if (await signingIn(
                                      email: provider.getUserEmail,
                                      password: _passward,
                                      context: context)) {
                                    Navigator.pushReplacement(
                                        context,
                                        MaterialPageRoute(
                                            builder: (context) => Complaint()));
                                  }
                                },
                              ),
                              SizedBox(
                                height: 50,
                              ),
                            ],
                          ),
                        ),
                      );
                    },
                  ),
                ),
              ),
            ],
          ),
        );
      },
    );
  }
}
