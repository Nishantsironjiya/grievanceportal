import 'dart:io';

import 'package:animated_text_kit/animated_text_kit.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:provider/provider.dart';
import 'package:iet_user_app/Components/Animated_text.dart';
import 'package:iet_user_app/Components/Button.dart';
import 'package:iet_user_app/Components/ShowDialog.dart';
import 'package:iet_user_app/Components/SnackBar.dart';
import 'package:iet_user_app/Components/Text_Field.dart';
import 'package:iet_user_app/Components/create_space.dart';
import 'package:iet_user_app/Components/showLoading.dart';
import 'package:iet_user_app/Firebase/FirebaseAuth.dart';
import 'package:iet_user_app/Functions/ImagePicker.dart';
import 'package:iet_user_app/Functions/Platform_Check.dart';
import 'package:iet_user_app/Functions/Upload_image_web.dart';
import 'package:iet_user_app/Provider/Data_Provider.dart';
import 'package:iet_user_app/Views/Sign_In.dart';

class SignUp extends StatefulWidget {
  @override
  _SignUpState createState() => _SignUpState();
}

class _SignUpState extends State<SignUp> {
  @override
  void initState() {
    Provider.of<DataProvider>(context, listen: false).cleardata();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    String _password1;
    String _password;
    final _scrollCtrl = ScrollController();
    List<String> _departmentList = [
      Provider.of<DataProvider>(context, listen: false).getDepartment,
      'MCA Department',
      'Computer Science Department',
      'Electronics Comm. Eng Department ',
      'Electrical Engineering  Department ',
      'Civil Engineering  Department',
      'Artificial Intelligence & Data Science  Department ',
      'Internet of Things Department'
    ];

    return Consumer<DataProvider>(
      builder: (context, provider, child) {
        return Scaffold(
          backgroundColor: Color(0xffFFFFFF),
          body: Row(
            children: [
              if (!checkPlatform())
                Expanded(
                  flex: 3,
                  child: Container(
                    decoration: BoxDecoration(
                        image: DecorationImage(
                      image: provider.signUpImage,
                      fit: BoxFit.cover,
                    )),
                  ),
                ),
              Expanded(
                flex: 2,
                child: Container(
                  child: Scrollbar(
                    controller: _scrollCtrl,
                    isAlwaysShown: !checkPlatform(),
                    thickness: 10,
                    child: ListView(
                      physics: !checkPlatform()
                          ? ClampingScrollPhysics()
                          : BouncingScrollPhysics(),
                      controller: _scrollCtrl,
                      padding:
                          EdgeInsets.symmetric(horizontal: 20, vertical: 20),
                      children: [
                        space(v: 50),
                        Text(
                          'Hey,',
                          style: TextStyle(
                              color: Colors.black,
                              fontFamily: 'log',
                              fontSize: 30),
                        ),
                        SizedBox(
                          height: 80,
                          child: ShowAnimatedText(
                            text:
                                TyperAnimatedText('Create your account here.'),
                          ),
                        ),
                        SizedBox(
                          height: 30,
                        ),
                        Center(
                          child: Stack(
                            alignment: Alignment.bottomRight,
                            children: [
                              CircleAvatar(
                                radius: 70,
                                backgroundImage: provider.getImage,
                                child: InkWell(
                                  onTap: () {},
                                ),
                              ),
                              CircleAvatar(
                                backgroundColor:
                                    Colors.white, // const Color(0xffF5F5F5),
                                child: IconButton(
                                  icon: Icon(
                                    Icons.camera_alt,
                                    color: Colors.black,
                                  ),
                                  onPressed: () async {
                                    if (kIsWeb) {
                                      await uploadWebProfile(context: context);
                                      // provider.bytesOfImage =
                                      //     await getImageWeb(context);
                                      // provider.setWebImage =
                                      //     provider.bytesOfImage;
                                    } else {
                                      provider.localPathOfImage =
                                          await getImage(context);
                                      provider.setLocalImage =
                                          File(provider.localPathOfImage);
                                    }
                                  },
                                ),
                              )
                            ],
                          ),
                        ),
                        space(v: 50),
                        Center(
                          child: ToggleButtons(
                            onPressed: (i) {
                              provider.changeToggleValue(index: i);
                            },
                            borderWidth: 3,
                            fillColor: const Color(0xffF5F5F5),
                            selectedColor: Colors.black,
                            selectedBorderColor: Colors.black,
                            hoverColor: Colors.lightBlue[50],
                            disabledColor: Colors.grey,
                            children: [
                              Container(
                                padding: EdgeInsets.all(15),
                                child: Column(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    Icon(
                                      FontAwesomeIcons.userGraduate,
                                      color: provider.toggleColorList[0],
                                    ),
                                    space(v: 10),
                                    Text(
                                      'Student',
                                      style: TextStyle(
                                        color: provider.toggleColorList[0],
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              Container(
                                padding: EdgeInsets.all(15),
                                child: Column(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    Icon(FontAwesomeIcons.chalkboardTeacher,
                                        color: provider.toggleColorList[1]),
                                    space(v: 10),
                                    Text(
                                      'Teacher',
                                      style: TextStyle(
                                        color: provider.toggleColorList[1],
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              Container(
                                padding: EdgeInsets.symmetric(
                                    horizontal: 20, vertical: 15),
                                child: Column(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    Icon(FontAwesomeIcons.user,
                                        color: provider.toggleColorList[2]),
                                    space(v: 10),
                                    Text(
                                      'Other',
                                      style: TextStyle(
                                        color: provider.toggleColorList[2],
                                      ),
                                    )
                                  ],
                                ),
                              ),
                            ],
                            isSelected: provider.toggleValueList,
                          ),
                        ),
                        space(),
                        TextFieldArea(
                          hint: 'Name',
                          fun: (v) => provider.setUserName = v,
                        ),
                        space(),
                        TextFieldArea(
                          hint: 'Email',
                          fun: (v) => provider.setUserEmail = v,
                        ),
                        space(),
                        TextFieldArea(
                          hint: 'Phone',
                          fun: (v) => provider.setUserPhoneNumber = v,
                        ),
                        space(),
                        TextFieldArea(
                          hint: 'Enrollment',
                          fun: (v) => provider.setEnrollment = v,
                        ),
                        space(),
                        Container(
                          padding: EdgeInsets.only(left: 20, right: 15),
                          decoration: BoxDecoration(
                            color: const Color(0xffF5F5F5),
                            borderRadius: BorderRadius.circular(12),
                          ),
                          child: DropdownButton(
                            iconSize: 30,
                            hint: Text('Select Department'),
                            isExpanded: true,
                            onChanged: (v) {
                              provider.setDeparment = v;
                            },
                            underline: Container(
                              color: Color(0xff8ACAC0),
                            ),
                            value: provider.getDepartment,
                            items: _departmentList
                                .map<DropdownMenuItem<String>>((String value) {
                              return DropdownMenuItem<String>(
                                value: value,
                                child: Text(value),
                              );
                            }).toList(),
                          ),
                        ),
                        space(),
                        TextFieldArea(
                          suffix: InkWell(
                            onTap: () {
                              provider.changeSecureText0Status();
                            },
                            child: Icon(
                              Icons.remove_red_eye,
                              size: 15,
                            ),
                          ),
                          state: provider.getSecureText0Status,
                          color: provider.text2FieldColor,
                          hint: 'Password',
                          fun: (v) => _password = v,
                        ),
                        space(),
                        TextFieldArea(
                          suffix: InkWell(
                            onTap: () {
                              provider.changeSecureText1Status();
                            },
                            child: Icon(
                              Icons.remove_red_eye,
                              size: 15,
                            ),
                          ),
                          state: provider.getSecureText1Status,
                          color: provider.text2FieldColor,
                          hint: 'Confirm Password',
                          fun: (v) => _password1 = v,
                        ),
                        SizedBox(
                          height: 60,
                        ),
                        SignInOutButton(
                          fun: () async {
                            if (provider.getUserType == null) {
                              showSnakbar(
                                context: context,
                                message: 'Please Select Your Catagory',
                              );
                            } else if (provider.getUserName == null ||
                                provider.getUserName.length == 0)
                              showSnakbar(
                                context: context,
                                message: 'Please Enter Name',
                              );
                            else if (provider.getUserEmail == null ||
                                provider.getUserEmail.length == 0 ||
                                (provider.getUserEmail.contains('ietengg.in') ==
                                        false &&
                                    provider.getUserType != UserType.Other))
                              showSnakbar(
                                context: context,
                                message: 'Please Enter Your College Email ID',
                              );
                            else if (provider.getUserPhoneNumber.length < 10)
                              showSnakbar(
                                context: context,
                                message: 'Please Enter Correct Phone Number',
                              );
                            else if (provider.getEnrollment.length == null ||
                                provider.getEnrollment.length == 0)
                              showSnakbar(
                                context: context,
                                message: 'Please Enter Your Enrollment Number',
                              );
                            else if (provider.getDepartment ==
                                'Select Department')
                              showSnakbar(
                                context: context,
                                message: 'Please Select Department',
                              );
                            else if (_password != _password1)
                              showSnakbar(
                                context: context,
                                message: 'Password Mismatch',
                              );
                            else {
                              showLoading(context);
                              try {
                                var _flag = await createUser(
                                    context: context,
                                    email: provider.getUserEmail,
                                    password: _password);
                                Navigator.pop(context);
                                if (_flag)
                                  showMsgDialog(
                                    context,
                                    AlertDialog(
                                      content: Text(
                                          'Acoount create sucessfully. Now please verify your account and login!'),
                                      actions: [
                                        TextButton(
                                          onPressed: () {
                                            Navigator.pushReplacement(
                                                context,
                                                MaterialPageRoute(
                                                    builder: (context) =>
                                                        SignIn()));
                                          },
                                          child: Text('OK'),
                                        ),
                                      ],
                                    ),
                                  );
                              } catch (e) {
                                Navigator.pop(context);
                                showSnakbar(
                                    context: context, message: e.message);
                              }
                            }
                          },
                          text: 'Create Account',
                        ),
                        SizedBox(
                          height: 50,
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ],
          ),
        );
      },
    );
  }
}
