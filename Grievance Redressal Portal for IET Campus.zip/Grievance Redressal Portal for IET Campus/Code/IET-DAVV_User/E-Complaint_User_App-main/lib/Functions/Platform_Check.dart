import 'dart:io' show Platform;

bool checkPlatform() {
  try {
    if (Platform.isAndroid || Platform.isIOS) {
      return true;
    }
  } catch (e) {}
  return false;
}