import 'package:image_picker/image_picker.dart';
import 'package:iet_user_app/Components/SnackBar.dart';

Future<dynamic> getImage(context) async {
  final pickedFile = await ImagePicker().getImage(source: ImageSource.gallery);
  if (pickedFile != null)
    return pickedFile.path;
  else {
    print('No Image Selected');
    showSnakbar(context: context, message: 'Please Select Picture');
    return null;
  }
}
