import 'package:universal_html/html.dart';

import 'package:flutter/cupertino.dart';
import 'package:flutter/foundation.dart';
import 'package:iet_user_app/Firebase/FirebaseStorage.dart';

Future<String> uploadWebAttachment({@required BuildContext context}) async {
  InputElement uploadInput = FileUploadInputElement();
  uploadInput.click();

  uploadInput.onChange.listen(
    (changeEvent) {
      final file = uploadInput.files.first;
      final reader = FileReader();
      reader.readAsDataUrl(file);
      reader.onLoadEnd.listen(
        (loadEndEvent) async {
          uploadAttachmentWeb(file: file, context: context);
        },
      );
    },
  );
  return null;
}

Future<String> uploadWebProfile({@required BuildContext context}) async {
  InputElement uploadInput = FileUploadInputElement();
  uploadInput.click();

  uploadInput.onChange.listen(
    (changeEvent) {
      final file = uploadInput.files.first;
      final reader = FileReader();
      reader.readAsDataUrl(file);
      reader.onLoadEnd.listen(
        (loadEndEvent) async {
          await uploadProfileWeb(file: file, context: context);
        },
      );
    },
  );
  return null;
}
