import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:iet_user_app/Components/SnackBar.dart';
import 'package:iet_user_app/Firebase/FirebaseStorage.dart';
import 'package:iet_user_app/Provider/Data_Provider.dart';

FirebaseFirestore _firestore = FirebaseFirestore.instance;

Future<void> storeUserData({@required BuildContext context}) async {
  DataProvider provider = Provider.of<DataProvider>(context, listen: false);
  try {
    // if (kIsWeb)
    // await uploadProfileWeb(context: context);
    // else
    if (!kIsWeb) await uploadProfile(context: context);
    await _firestore.collection('Users').doc('${provider.getUserEmail}').set(
      {
        'Name': provider.getUserName,
        'Email': provider.getUserEmail,
        'Department': provider.getDepartment,
        'Category': provider.getUserTypeForDB(),
        'Enrollment': provider.getEnrollment,
        'Profile': provider.getProfileURL,
        'Phone': provider.getUserPhoneNumber,
      },
    );
  } catch (e) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(e.message),
      ),
    );
  }
}

Future<bool> checkUserAlreadyExist({String email}) async {
  try {
    return true;
  } catch (e) {
    print(e);
  }
  return false;
}

Future<String> submitComplaint(
    {@required BuildContext context,
    @required String subject,
    @required String complaint,
    @required String attachment}) async {
  DataProvider provider = Provider.of<DataProvider>(context, listen: false);
  try {
    if (attachment != null) {
      try {
        attachment = await uploadAttachment(
            context: context, path: attachment, id: provider.getUserEmail);
      } catch (e) {
        Navigator.pop(context);
        showSnakbar(context: context, message: e.message);
        return null;
      }
    }
    if (kIsWeb) {
      attachment = provider.getwebAttachmentUrl;
    }
    var result = await _firestore.collection('Complaints').add({
      'Email': provider.getUserEmail,
      'Subject': subject,
      'Complaint': complaint,
      'Date': DateTime.now(),
      'Attachment': attachment,
      'Status': 'Submitted',
    });
    Navigator.pop(context);
    return result.id;
  } catch (e) {
    Navigator.pop(context);
    showSnakbar(context: context, message: e.message);
    return null;
  }
}

Future<DocumentSnapshot> fatchUserData({@required String email}) async {
  return await _firestore.collection('Users').doc(email).get();
}

Future<String> searchComplaintStatus({@required String ref}) async {
  String _ans;
  try {
    DocumentSnapshot _data =
        await _firestore.collection('Complaints').doc(ref).get();

    if (_data.exists) {
      String a = _data.data()['Status'];
      Timestamp c = _data.data()['Date'];
      String day = c.toDate().day.toString();
      String month = c.toDate().month.toString();
      String year = c.toDate().year.toString();
      String hour = c.toDate().hour.toString();
      String minute = c.toDate().minute.toString();
      _ans = a +
          ' on ' +
          hour +
          ':' +
          minute +
          '  at  ' +
          day +
          '-' +
          month +
          '-' +
          year;
    } else {
      _data = await _firestore.collection('Complaint History').doc(ref).get();
      if (_data.exists) {
        String a = _data.data()['Status'];
        Timestamp c = _data.data()['Date'];
        String day = c.toDate().day.toString();
        String month = c.toDate().month.toString();
        String year = c.toDate().year.toString();
        String hour = c.toDate().hour.toString();
        String minute = c.toDate().minute.toString();
        _ans = a +
            ' on ' +
            hour +
            ':' +
            minute +
            '  at  ' +
            day +
            '-' +
            month +
            '-' +
            year;
      } else
        _ans = 'No record found';
    }
  } catch (e) {
    _ans = 'No record found';
  }
  return _ans;
}
