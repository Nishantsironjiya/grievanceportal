import 'dart:io';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:iet_user_app/Components/SnackBar.dart';
import 'package:iet_user_app/Components/showLoading.dart';
import 'package:iet_user_app/Provider/Data_Provider.dart';

FirebaseStorage _storage = FirebaseStorage.instance;

Future<void> uploadProfile({BuildContext context}) async {
  DataProvider provider = Provider.of<DataProvider>(context, listen: false);
  File file = File(provider.localPathOfImage);
  try {
    await _storage
        .ref('User Profile\'s/(${provider.getUserEmail}).png')
        .putFile(file);
    provider.setProfileURL = await _storage
        .ref('User Profile\'s/(${provider.getUserEmail}).png')
        .getDownloadURL();
  } catch (e) {
    print(e);
    showSnakbar(context: context, message: e.message);
  }
}

Future<String> uploadAttachment(
    {BuildContext context, String path, String id}) async {
  File file = File(path);
  String _rd = DateTime.now().toString();
  try {
    await _storage.ref('Attachment/($id)$_rd.png').putFile(file);
    return await _storage.ref('Attachment/($id)$_rd.png').getDownloadURL();
  } catch (e) {
    Navigator.pop(context);
    showSnakbar(context: context, message: e.message);
    return null;
  }
}

Future<void> uploadProfileWeb(
    {@required BuildContext context, @required dynamic file}) async {
  DataProvider provider = Provider.of<DataProvider>(context, listen: false);
  // Blob blob = Blob(provider.bytesOfImage);
  try {
    showLoading(context);
    await _storage
        .ref('User Profile\'s/(${provider.getUserEmail}).png')
        .putBlob(file);
    provider.imageLoadedIndicater();
    Navigator.pop(context);
    provider.setProfileURL = await _storage
        .ref('User Profile\'s/(${provider.getUserEmail}).png')
        .getDownloadURL();
  } catch (e) {
    print(e);
    showSnakbar(context: context, message: e.message);
  }
}

Future<String> uploadAttachmentWeb(
    {@required dynamic file, @required BuildContext context}) async {
  DataProvider provider = Provider.of<DataProvider>(context, listen: false);
  String _rd = DateTime.now().toString();
  try {
    provider.setClipColor = Colors.orange;
    await _storage
        .ref('Attachment/(${provider.getUserEmail})$_rd.png')
        .putBlob(file);
    provider.setwebAttachmentUrl = await _storage
        .ref('Attachment/(${provider.getUserEmail})$_rd.png')
        .getDownloadURL();
    return provider.getwebAttachmentUrl;
  } catch (e) {
    print(e);
    return null;
  }
}
