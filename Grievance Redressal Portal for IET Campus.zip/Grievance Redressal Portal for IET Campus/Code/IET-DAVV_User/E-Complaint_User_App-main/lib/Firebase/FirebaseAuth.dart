import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:iet_user_app/Firebase/FirebaseFirestore.dart';
import 'package:iet_user_app/Provider/Data_Provider.dart';

FirebaseAuth _auth = FirebaseAuth.instance;

Future<bool> createUser(
    {BuildContext context, String email, String password}) async {
  try {
    await _auth.createUserWithEmailAndPassword(
        email: email, password: password);
    await sendVerificationEmail();
    await storeUserData(context: context);
    return true;
  } catch (e) {
    print(e);
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(e.message),
      ),
    );
    return false;
  }
}

Future<void> sendVerificationEmail() async {
  await _auth.currentUser.sendEmailVerification();
}

Future<bool> signingIn(
    {String email, String password, BuildContext context}) async {
  try {
    await _auth.signInWithEmailAndPassword(email: email, password: password);
    await Provider.of<DataProvider>(context, listen: false).setUserData();
    Navigator.pop(context);
    return true;
  } catch (e) {
    Navigator.pop(context);
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(e.message),
      ),
    );
    print(e);
    return false;
  }
}

bool isVerifiedEmail() {
  return _auth.currentUser.emailVerified;
}

Future<String> resetPassword({String email}) async {
  try {
    await _auth.sendPasswordResetEmail(email: email);
    return 'Check your email to reset password';
  } catch (e) {
    return e.message;
  }
}

Future<void> signOut() async {
  await _auth.signOut();
}
