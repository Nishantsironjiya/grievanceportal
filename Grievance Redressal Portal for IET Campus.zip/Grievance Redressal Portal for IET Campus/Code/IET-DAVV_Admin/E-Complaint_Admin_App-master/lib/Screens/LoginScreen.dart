import 'dart:ui';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:complaint_portal_admin_app/Components/GradientButton.dart';
import 'package:complaint_portal_admin_app/Components/Painter.dart';
import 'package:complaint_portal_admin_app/Constant.dart';
import 'package:complaint_portal_admin_app/Screens/ComplaintDashBoardScreen.dart';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';

class LogInScreen extends StatefulWidget {
  static String id = 'LoginScreen';
  @override
  _LogInScreenState createState() => _LogInScreenState();
}

class _LogInScreenState extends State<LogInScreen> {
  bool _star = true;
  @override
  Widget build(BuildContext context) {
    double width = MediaQuery.of(context).size.width;
    String email, password;
    return Scaffold(
      backgroundColor: Colors.transparent,
      body: FutureBuilder(
        future:
            FirebaseFirestore.instance.collection('admin').doc('data').get(),
        builder: (BuildContext context, AsyncSnapshot<dynamic> snapshot) {
          if (snapshot.hasData)
            return Container(
              decoration: kBoxDecoration,
              child: Center(
                child: Container(
                  decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(5)),
                  height: MediaQuery.of(context).size.height / 2,
                  width: MediaQuery.of(context).size.width / 2,
                  child: ListView(
                    padding: EdgeInsets.all(40),
                    children: [
                      Container(
                        constraints: BoxConstraints(maxHeight: 40),
                        child: FittedBox(
                          child: Text(
                            'Welcome',
                            style: TextStyle(color: Colors.blue),
                          ),
                        ),
                      ),
                      SizedBox(
                        height: 20,
                      ),
                      TextField(
                        style: TextStyle(color: Colors.black),
                        // textAlign: TextAlign.center,
                        decoration: InputDecoration(
                          hintText: 'Email',
                          hintStyle: TextStyle(
                            color: Colors.grey,
                          ),
                          // prefix: Icon(
                          //   Icons.person,
                          //   color: Colors.black,
                          // ),
                        ),
                        onChanged: (val) {
                          email = val;
                        },
                      ),
                      SizedBox(
                        height: 10,
                      ),
                      TextField(
                        obscureText: _star,
                        style: TextStyle(color: Colors.black),
                        obscuringCharacter: '*',
                        // textAlign: TextAlign.center,
                        decoration: InputDecoration(
                          hintText: 'Password',
                          hintStyle: TextStyle(
                            color: Colors.grey,
                          ),
                          // prefix: Icon(Icons.lock, color: Colors.black),
                          suffix: IconButton(
                            icon: _star
                                ? FaIcon(FontAwesomeIcons.eye,
                                    color: Colors.cyan)
                                : FaIcon(FontAwesomeIcons.eyeSlash,
                                    color: Colors.cyan),
                            onPressed: () {
                              setState(
                                () {
                                  _star = !_star;
                                },
                              );
                            },
                          ),
                        ),
                        onChanged: (val) {
                          password = val;
                        },
                      ),
                      SizedBox(
                        height: 20,
                      ),
                      GradientButton(
                        fun: () {
                          try {
                            var data = snapshot.data.data();
                            ScaffoldMessenger.of(context)
                                .removeCurrentSnackBar();
                            // print(data);
                            if (data['email'] == email &&
                                data['password'] == password)
                              Navigator.pushReplacement(
                                context,
                                MaterialPageRoute(
                                  builder: (context) =>
                                      ComplaintDashBoardScreen(),
                                ),
                              );
                            else if ((data['email'] != email &&
                                data['password'] != password)) {
                              ScaffoldMessenger.of(context).showSnackBar(
                                  SnackBar(
                                      content:
                                          Text('Wrong Email and Password')));
                              return;
                            } else if ((data['email'] != email)) {
                              ScaffoldMessenger.of(context).showSnackBar(
                                  SnackBar(content: Text('Wrong Email')));
                              return;
                            } else {
                              ScaffoldMessenger.of(context).showSnackBar(
                                  SnackBar(content: Text('Wrong Password')));
                              return;
                            }
                          } catch (e) {
                            ScaffoldMessenger.of(context).showSnackBar(
                                SnackBar(content: Text(e.message)));
                          }
                        },
                      ),
                    ],
                  ),
                ),
              ),
            );
          return Center(child: CircularProgressIndicator());
        },
      ),
      bottomSheet: Container(
        decoration: kBoxDecoration,
        child: CustomPaint(
          size: Size(
              width,
              ((width / 2) * 0.08333333333333333)
                  .toDouble()), //You can Replace [WIDTH] with your desired width for Custom Paint and height will be calculated automatically
          painter: RPSCustomPainter(),
        ),
      ),
    );
  }
}
