import 'dart:ui';
import 'package:complaint_portal_admin_app/Components/AppBarButton.dart';
import 'package:complaint_portal_admin_app/Components/ComplaintTile.dart';
import 'package:complaint_portal_admin_app/Function/Date.dart';
import 'package:complaint_portal_admin_app/Screens/History.dart';
import 'package:complaint_portal_admin_app/Screens/LoginScreen.dart';
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';

Widget tempWidget = Center(
  child: Text('Select Complaint to get Details'),
);
int prevIndex = -1;
int currentStep = 0;
List<Color> colorList = [];
List<int> statusList = [];
int length = 0;
QuerySnapshot querySnapshot;
getComplaintList() async {
  return await FirebaseFirestore.instance.collection('Complaints').get();
}

class ComplaintDashBoardScreen extends StatefulWidget {
  final String department;

  const ComplaintDashBoardScreen({Key key, this.department = ''})
      : super(key: key);
  @override
  _ComplaintDashBoardScreenState createState() =>
      _ComplaintDashBoardScreenState();
}

class _ComplaintDashBoardScreenState extends State<ComplaintDashBoardScreen> {
  @override
  void initState() {
    tempWidget = Center(child: Text('Select Complaint to get Details'));
    getComplaintList().then((result) {
      setState(() {
        prevIndex = -1;
        colorList.clear();
        querySnapshot = result;
        length = querySnapshot.docs.length;
      });
    });
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    final _scCTRL = ScrollController();
    return Scaffold(
      backgroundColor: Color(0xff212121),
      appBar: AppBar(
        leading: Image.asset('assets/logoFinal.jpg'),
        title: Text(
          'IET Complaint Portal',
          style: TextStyle(fontWeight: FontWeight.bold),
        ),
        automaticallyImplyLeading: false,
        backgroundColor: Color(0xff212121),
        actions: [
          AppBarButton(
            fun: () {
              Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (context) => HistoryInformation()));
            },
            icon: FontAwesomeIcons.history,
            text: 'History',
          ),
          AppBarButton(
            fun: () {
              Navigator.pushAndRemoveUntil(
                  context,
                  MaterialPageRoute(builder: (context) => LogInScreen()),
                  (route) => false);
            },
            icon: Icons.logout,
            text: 'Log Out',
          ),
        ],
      ),
      body: Container(
        padding: EdgeInsets.all(5),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Expanded(
              child: Container(
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(20),
                  // color: Color(0xff30555C),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    ListTile(
                      contentPadding:
                          EdgeInsets.only(left: 20, right: 20, top: 15),
                      title: Text(
                        'Complaints',
                        style: TextStyle(
                          fontWeight: FontWeight.w500,
                          fontSize: 22,
                        ),
                      ),
                      trailing: Container(
                        decoration: BoxDecoration(
                          color: Color(0xff30555c),
                          borderRadius: BorderRadius.circular(10),
                          border: Border.all(color: Colors.cyan),
                        ),
                        child: Padding(
                          padding: const EdgeInsets.all(10.0),
                          child: Text(
                            length.toString(),
                            style: TextStyle(
                              fontWeight: FontWeight.w500,
                              fontSize: 22,
                            ),
                          ),
                        ),
                      ),
                    ),
                    Divider(
                      color: Colors.white,
                      thickness: 2,
                      indent: 20,
                      endIndent: 20,
                    ),
                    Expanded(
                        child: querySnapshot != null
                            ? Scrollbar(
                                isAlwaysShown: true,
                                controller: _scCTRL,
                                child: ListView.builder(
                                    controller: _scCTRL,
                                    itemCount: querySnapshot.docs.length,
                                    itemBuilder: (context, index) {
                                      colorList.add(Colors.white10);
                                      statusList.add(selectStep(querySnapshot
                                          .docs[index]
                                          .data()['Status']));

                                      if (querySnapshot.docs.length == 0) {
                                        print('NO data');
                                        setState(() {
                                          tempWidget = Center(
                                            child: Text('No Data'),
                                          );
                                        });
                                        return Center(
                                          child: Text('No Records'),
                                        );
                                      }

                                      return Padding(
                                        padding: EdgeInsets.symmetric(
                                            horizontal: 20, vertical: 10),
                                        child: ClipRRect(
                                          borderRadius:
                                              BorderRadius.circular(20),
                                          child: ListTile(
                                            contentPadding:
                                                EdgeInsets.symmetric(
                                                    horizontal: 20),
                                            // leading: findcatageryIcon(
                                            //     '${querySnapshot.docs[index].data()['Catagery']}'),
                                            tileColor: colorList[index],
                                            onTap: () async {
                                              var data = await FirebaseFirestore
                                                  .instance
                                                  .collection('Users')
                                                  .doc(
                                                      '${querySnapshot.docs[index].data()['Email']}')
                                                  .get();

                                              setState(() {
                                                if (prevIndex >= 0) {
                                                  colorList[prevIndex] =
                                                      Colors.white10;
                                                }
                                                prevIndex = index;
                                                colorList[index] =
                                                    Colors.white30;
                                                tempWidget = ComplaintTile(
                                                  complaintData: querySnapshot
                                                      .docs[index]
                                                      .data(),
                                                  userData: data.data(),
                                                  id: querySnapshot
                                                      .docs[index].id,
                                                  currentStep:
                                                      statusList[index],
                                                  fun: (string) {
                                                    statusList[index] =
                                                        selectStep(string);
                                                  },
                                                );
                                              });
                                            },
                                            title: Padding(
                                              padding:
                                                  const EdgeInsets.all(8.0),
                                              child: Text(
                                                querySnapshot.docs[index]
                                                    .data()['Subject'],
                                                maxLines: 2,
                                                softWrap: true,
                                                overflow: TextOverflow.ellipsis,
                                                style: TextStyle(
                                                  fontWeight: FontWeight.bold,
                                                  fontSize: 20,
                                                ),
                                              ),
                                            ),
                                            subtitle: Padding(
                                              padding:
                                                  const EdgeInsets.all(8.0),
                                              child: Text(
                                                querySnapshot.docs[index]
                                                    .data()['Complaint'],
                                                maxLines: 2,
                                                softWrap: true,
                                                overflow: TextOverflow.ellipsis,
                                                style: TextStyle(),
                                              ),
                                            ),
                                            trailing: Padding(
                                              padding: const EdgeInsets.only(
                                                  left: 10, bottom: 5),
                                              child: Text(
                                                getDateTime(querySnapshot
                                                    .docs[index]
                                                    .data()['Date']),
                                                style: TextStyle(fontSize: 15),
                                              ),
                                            ),
                                          ),
                                        ),
                                      );
                                    }),
                              )
                            : Center(child: CircularProgressIndicator())),
                  ],
                ),
              ),
            ),
            SizedBox(
              width: 10,
            ),
            Expanded(
              child: Container(
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.only(
                    topLeft: Radius.circular(20),
                    bottomLeft: Radius.circular(20),
                  ),
                  color: Color(0xff30555C),
                ),
                child: tempWidget,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

findcatageryIcon(String s) {
  switch (s) {
    case 'Teacher':
      return FontAwesomeIcons.chalkboardTeacher;
    case 'Student':
      return FontAwesomeIcons.userGraduate;
    default:
      return FontAwesomeIcons.user;
  }
}

int selectStep(String s) {
  switch (s) {
    case 'Seen':
      return 0;
    case 'In Progress':
      return 1;
    case 'Completed':
      return 2;
    default:
      return 0;
  }
}
