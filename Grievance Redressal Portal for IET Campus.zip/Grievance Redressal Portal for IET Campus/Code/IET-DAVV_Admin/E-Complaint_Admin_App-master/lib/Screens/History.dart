import 'dart:ui';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:complaint_portal_admin_app/Components/AppBarButton.dart';
import 'package:complaint_portal_admin_app/Function/Date.dart';
import 'package:complaint_portal_admin_app/Screens/ComplaintDashBoardScreen.dart';
import 'package:complaint_portal_admin_app/Screens/LoginScreen.dart';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';

class HistoryInformation extends StatelessWidget {
  final _scCTRL = ScrollController();
  @override
  Widget build(BuildContext context) {
    Stream complaintslist = FirebaseFirestore.instance
        .collection('Complaint History')
        .snapshots(includeMetadataChanges: true);

    return StreamBuilder<QuerySnapshot>(
      stream: complaintslist,
      builder: (BuildContext context, AsyncSnapshot<QuerySnapshot> snapshot) {
        if (snapshot.hasError) {
          return Scaffold(
            body: Center(
              child: Text('Something went wrong'),
            ),
          );
        }

        if (snapshot.connectionState == ConnectionState.waiting) {
          return Scaffold(
            body: Center(child: CircularProgressIndicator()),
          );
        }
        return SafeArea(
          child: Scaffold(
            appBar: AppBar(
              title: Text(
                'Complaint History',
                style: TextStyle(fontWeight: FontWeight.bold),
              ),
              automaticallyImplyLeading: false,
              backgroundColor: Color(0xff212121),
              actions: [
                AppBarButton(
                  fun: () {
                    Navigator.pushReplacement(
                        context,
                        MaterialPageRoute(
                            builder: (context) => ComplaintDashBoardScreen()));
                  },
                  icon: FontAwesomeIcons.history,
                  text: 'New Complaints',
                ),
                AppBarButton(
                  fun: () {
                    Navigator.pushAndRemoveUntil(
                        context,
                        MaterialPageRoute(builder: (context) => LogInScreen()),
                        (route) => false);
                  },
                  icon: Icons.logout,
                  text: 'Log Out',
                ),
              ],
            ),
            body: Scrollbar(
              isAlwaysShown: true,
              controller: _scCTRL,
              child: ListView(
                controller: _scCTRL,
                children: snapshot.data.docs.map(
                  (DocumentSnapshot document) {
                    return Padding(
                      padding: const EdgeInsets.only(left: 10,right: 20,top: 10,bottom: 10),
                      child: ClipRRect(
                        borderRadius: BorderRadius.circular(20),
                        child: ListTile(
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(20),
                          ),
                          tileColor: Colors.white10,
                          contentPadding: EdgeInsets.only(
                              left: 50, top: 10, bottom: 10, right: 20),
                          // leading: findcatageryIcon(document.data()['Catagery']),
                          title: Text(
                            document.data()['Subject'],
                            style: TextStyle(
                                fontWeight: FontWeight.bold, fontSize: 20),
                          ),
                          trailing: FittedBox(
                            child: Row(
                              children: [
                                OutlinedButton(
                                  onPressed: () {
                                    showDialog(
                                        builder: (context) => AlertDialog(
                                              title: Text(
                                                document.data()['Subject'],
                                                style: TextStyle(
                                                    fontWeight:
                                                        FontWeight.bold),
                                              ),
                                              content: Text(
                                                  document.data()['Complaint']),
                                              actions: [
                                                OutlinedButton(
                                                  onPressed: () =>
                                                      Navigator.pop(context),
                                                  child: Text(
                                                    'OK',
                                                    style: TextStyle(
                                                        color: Colors.white),
                                                  ),
                                                )
                                              ],
                                            ),
                                        context: context);
                                  },
                                  child: Text(
                                    'View Complaint',
                                    style: TextStyle(color: Colors.white),
                                  ),
                                ),
                                SizedBox(
                                  width: 20,
                                ),
                                OutlinedButton(
                                  onPressed: () async {
                                    String name = 'Error';
                                    String number = 'Unable to fatch User data';
                                    String email = 'not found';
                                    String url = '';
                                    showDialog(
                                        context: context,
                                        builder: (context) => Center(
                                            child:
                                                CircularProgressIndicator()));

                                    try {
                                      var data = await FirebaseFirestore
                                          .instance
                                          .collection('Users')
                                          .doc(document.data()['Email'])
                                          .get();

                                      name = data.data()['Name'];
                                      number = data.data()['Phone'];
                                      email = data.data()['Email'];
                                      url = data.data()['Profile'];
                                    } catch (e) {
                                      Navigator.pop(context);
                                      ScaffoldMessenger.of(context)
                                          .showSnackBar(
                                              SnackBar(content: Text(e.msg)));
                                      return;
                                    }
                                    Navigator.pop(context);
                                    showDialog(
                                      context: context,
                                      builder: (context) {
                                        return Dialog(
                                          child: Row(
                                            children: [
                                              Expanded(
                                                flex: 2,
                                                child: Container(
                                                  child: FadeInImage(
                                                    placeholder: AssetImage(
                                                        'assets/loader4.gif'),
                                                    image: NetworkImage(url),
                                                  ),
                                                ),
                                              ),
                                              Expanded(
                                                flex: 1,
                                                child: Container(
                                                  child: Column(
                                                    mainAxisAlignment:
                                                        MainAxisAlignment
                                                            .spaceEvenly,
                                                    crossAxisAlignment:
                                                        CrossAxisAlignment
                                                            .center,
                                                    children: [
                                                      Spacer(),
                                                      Spacer(),
                                                      ListTile(
                                                        leading: Icon(
                                                            FontAwesomeIcons
                                                                .user),
                                                        title: Text(name),
                                                      ),
                                                      ListTile(
                                                        leading: Icon(
                                                            FontAwesomeIcons
                                                                .phone),
                                                        title: SelectableText(
                                                            number),
                                                      ),
                                                      ListTile(
                                                        leading:
                                                            Icon(Icons.email),
                                                        title: SelectableText(
                                                          email,
                                                        ),
                                                      ),
                                                      Spacer(),
                                                      OutlinedButton(
                                                          onPressed: () {
                                                            Navigator.pop(
                                                                context);
                                                          },
                                                          child: Text(
                                                            'OK',
                                                            style: TextStyle(
                                                                color: Colors
                                                                    .white),
                                                          )),
                                                      Spacer(),
                                                    ],
                                                  ),
                                                ),
                                              ),
                                            ],
                                          ),
                                        );
                                      },
                                    );
                                  },
                                  child: Text(
                                    'Get User Data',
                                    style: TextStyle(color: Colors.white),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          subtitle: Padding(
                            padding: const EdgeInsets.only(top: 3),
                            child: Text(
                              '${document.data()['Status']} on ${getDateTime(document.data()['Date'])}',
                            ),
                          ),
                        ),
                      ),
                    );
                  },
                ).toList(),
              ),
            ),
          ),
        );
      },
    );
  }
}

findcatageryIcon(String s) {
  switch (s) {
    case 'Teacher':
      return Icon(
        FontAwesomeIcons.chalkboardTeacher,
      );
    case 'Student':
      return Icon(FontAwesomeIcons.userGraduate);
    default:
      return Icon(FontAwesomeIcons.user);
  }
}
