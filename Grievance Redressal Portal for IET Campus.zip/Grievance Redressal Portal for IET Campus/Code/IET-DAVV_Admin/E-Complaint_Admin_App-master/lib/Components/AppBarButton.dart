import 'package:flutter/material.dart';

class AppBarButton extends StatelessWidget {
  final IconData icon;
  final String text;
  final Function fun;
  const AppBarButton({
    Key key,
    this.icon,
    this.text,
    this.fun,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
      child: OutlinedButton.icon(
        style: ButtonStyle(
          overlayColor:
              MaterialStateProperty.resolveWith((states) => Colors.black45),
        ),
        onPressed: fun,
        icon: Icon(
          icon,
          color: Colors.white,
        ),
        label: Text(
          text,
          style: TextStyle(color: Colors.white),
        ),
      ),
    );
  }
}