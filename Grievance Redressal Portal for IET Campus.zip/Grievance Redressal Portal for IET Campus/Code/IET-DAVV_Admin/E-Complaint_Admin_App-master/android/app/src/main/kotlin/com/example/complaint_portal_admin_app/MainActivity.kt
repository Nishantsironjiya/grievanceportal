package com.example.complaint_portal_admin_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
